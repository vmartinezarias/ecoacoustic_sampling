"""Step VII: search recorder-constrained subsets of tessellation poles.

The algorithm starts from an existing Complete point design and a polygon
Tessellation. It computes one pole of inaccessibility per tile, summarizes the
same landscape proxy around Complete points and all tile poles, and searches
for subsets containing exactly the requested number of recorders.

Candidate subsets are compared with BOTH references:
  1) the Complete design, and
  2) the full tessellation design (one pole per valid tile).

Ranking uses the same distributional effect sizes already exposed by MILEVA:
KS D and Wasserstein-1. Wasserstein is divided by the observed proxy range so
it is on a roughly 0-1 scale like KS D. The four distances (two references x
two metrics) receive equal weight. KS p-values and S10_sorted_delta are
reported but are not optimized.
"""

import itertools
import math
import random

import numpy as np
import processing
from qgis.PyQt.QtCore import QMetaType
from qgis.core import (
    Qgis,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsMemoryProviderUtils,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
    QgsProcessingUtils,
)

from ..citation import CITATION
from ..output_names import name_output


def _ks_from_sorted(reference_sorted, sample_sorted):
    """Two-sample KS statistic and asymptotic p-value; inputs are sorted."""
    a = reference_sorted
    b = sample_sorted
    grid = np.concatenate([a, b])
    cdf_a = np.searchsorted(a, grid, side="right") / a.size
    cdf_b = np.searchsorted(b, grid, side="right") / b.size
    d = float(np.max(np.abs(cdf_a - cdf_b)))
    if d == 0.0:
        return 0.0, 1.0
    n, m = a.size, b.size
    en = n * m / (n + m)
    lam = (np.sqrt(en) + 0.12 + 0.11 / np.sqrt(en)) * d
    j = np.arange(1, 101)
    p = 2.0 * np.sum(((-1.0) ** (j - 1)) * np.exp(-2.0 * (lam ** 2) * (j ** 2)))
    return d, float(min(1.0, max(0.0, p)))


def _wasserstein_from_sorted(reference_sorted, sample_sorted):
    """True one-dimensional Wasserstein-1 distance for sorted arrays."""
    grid = np.sort(np.concatenate([reference_sorted, sample_sorted]))
    if grid.size < 2:
        return 0.0
    deltas = np.diff(grid)
    cdf_a = np.searchsorted(reference_sorted, grid[:-1], side="right") / reference_sorted.size
    cdf_b = np.searchsorted(sample_sorted, grid[:-1], side="right") / sample_sorted.size
    return float(np.sum(np.abs(cdf_a - cdf_b) * deltas))


def _s10_delta(reference_sorted, sample_sorted):
    count = min(reference_sorted.size, sample_sorted.size)
    if count == 0:
        return float("nan")
    return float(np.mean(np.abs(reference_sorted[:count] - sample_sorted[:count])))


def _scenario_metrics(sample_values, complete_sorted, tess_sorted, proxy_span):
    sample_sorted = np.sort(np.asarray(sample_values, dtype=float))

    ks_complete, p_complete = _ks_from_sorted(complete_sorted, sample_sorted)
    w_complete = _wasserstein_from_sorted(complete_sorted, sample_sorted)
    s10_complete = _s10_delta(complete_sorted, sample_sorted)

    ks_tess, p_tess = _ks_from_sorted(tess_sorted, sample_sorted)
    w_tess = _wasserstein_from_sorted(tess_sorted, sample_sorted)
    s10_tess = _s10_delta(tess_sorted, sample_sorted)

    span = proxy_span if proxy_span > 0 else 1.0
    score = float((ks_complete + ks_tess + w_complete / span + w_tess / span) / 4.0)

    return {
        "score": score,
        "ks_complete": ks_complete,
        "p_complete": p_complete,
        "w_complete": w_complete,
        "s10_complete": s10_complete,
        "ks_tess": ks_tess,
        "p_tess": p_tess,
        "w_tess": w_tess,
        "s10_tess": s10_tess,
    }


def _quantile_seed(candidate_values, complete_values, tess_values, n, complete_weight=0.5):
    """Deterministic starting subset that follows target proxy quantiles."""
    q = (np.arange(n, dtype=float) + 0.5) / n
    target = (
        complete_weight * np.quantile(complete_values, q)
        + (1.0 - complete_weight) * np.quantile(tess_values, q)
    )
    available = set(range(len(candidate_values)))
    chosen = []
    for value in target:
        idx = min(available, key=lambda j: (abs(candidate_values[j] - value), j))
        chosen.append(idx)
        available.remove(idx)
    return tuple(sorted(chosen))


class RecorderConstrainedScenariosAlgorithm(QgsProcessingAlgorithm):
    COMPLETE = "COMPLETE"
    TILES = "TILES"
    RASTER = "RASTER"
    RADIUS = "RADIUS"
    TOLERANCE = "TOLERANCE"
    N_RECORDERS = "N_RECORDERS"
    MAX_SCENARIOS = "MAX_SCENARIOS"
    TRIALS = "TRIALS"
    SEED = "SEED"
    FULL_TESSELLATION = "FULL_TESSELLATION"
    SCENARIOS = "SCENARIOS"
    TABLE = "TABLE"

    EXACT_LIMIT = 50000

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.COMPLETE, "Complete scenario points",
            types=[Qgis.ProcessingSourceType.VectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.TILES, "Tessellation tiles",
            types=[Qgis.ProcessingSourceType.VectorPolygon]))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER, "Landscape proxy raster"))
        self.addParameter(QgsProcessingParameterNumber(
            self.RADIUS, "Buffer radius for proxy mean (meters)",
            type=Qgis.ProcessingNumberParameterType.Double,
            defaultValue=200.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.TOLERANCE, "Pole tolerance (map units)",
            type=Qgis.ProcessingNumberParameterType.Double,
            defaultValue=1.0, minValue=0.01))
        self.addParameter(QgsProcessingParameterNumber(
            self.N_RECORDERS, "Available recorders / points per scenario",
            type=Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=20, minValue=1))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_SCENARIOS, "Maximum best scenarios to return (1-5)",
            type=Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=5, minValue=1, maxValue=5))
        self.addParameter(QgsProcessingParameterNumber(
            self.TRIALS, "Search trials when exhaustive search is not feasible",
            type=Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=3000, minValue=100, maxValue=200000))
        self.addParameter(QgsProcessingParameterNumber(
            self.SEED, "Search seed (reproducible)",
            type=Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=12345))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.FULL_TESSELLATION, "Full tessellation poles with proxy mean"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.SCENARIOS, "Top recorder-constrained scenarios"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.TABLE, "Scenario comparison table",
            type=Qgis.ProcessingSourceType.Vector))

    @staticmethod
    def _memory_points(name, source_features, crs, id_kind="source"):
        fields = QgsFields()
        fields.append(QgsField("mileva_id", QMetaType.Type.Int))
        fields.append(QgsField("source_id", QMetaType.Type.QString))
        layer = QgsMemoryProviderUtils.createMemoryLayer(
            name, fields, Qgis.WkbType.Point, crs)
        provider = layer.dataProvider()
        info = {}
        out_features = []
        idx = 0
        for feature in source_features:
            geom = feature.geometry()
            if geom.isNull() or geom.isEmpty():
                continue
            source_id = str(feature.id())
            if id_kind == "tile" and feature.fields().indexFromName("tile_id") >= 0:
                try:
                    source_id = str(feature["tile_id"])
                except Exception:
                    source_id = str(feature.id())
            out = QgsFeature(fields)
            out.setGeometry(QgsGeometry(geom))
            out.setAttributes([idx, source_id])
            out_features.append(out)
            info[idx] = (source_id, QgsGeometry(geom))
            idx += 1
        if not out_features:
            raise QgsProcessingException(f"{name} contains no valid point geometries.")
        if not provider.addFeatures(out_features):
            raise QgsProcessingException(f"Could not prepare temporary points for {name}.")
        layer.updateExtents()
        return layer, info

    @staticmethod
    def _zonal_means(point_layer, raster, radius, context, feedback):
        buffered = processing.run("native:buffer", {
            "INPUT": point_layer,
            "DISTANCE": radius,
            "SEGMENTS": 16,
            "DISSOLVE": False,
            "END_CAP_STYLE": 0,
            "JOIN_STYLE": 0,
            "OUTPUT": "TEMPORARY_OUTPUT",
        }, context=context, feedback=feedback, is_child_algorithm=True)["OUTPUT"]
        zonal = processing.run("native:zonalstatisticsfb", {
            "INPUT": buffered,
            "INPUT_RASTER": raster,
            "RASTER_BAND": 1,
            "COLUMN_PREFIX": "mileva_",
            "STATISTICS": [2],
            "OUTPUT": "TEMPORARY_OUTPUT",
        }, context=context, feedback=feedback, is_child_algorithm=True)["OUTPUT"]
        layer = QgsProcessingUtils.mapLayerFromString(zonal, context)
        if layer is None:
            raise QgsProcessingException("Could not load zonal-statistics result.")
        id_idx = layer.fields().indexFromName("mileva_id")
        mean_idx = layer.fields().indexFromName("mileva_mean")
        if id_idx < 0 or mean_idx < 0:
            raise QgsProcessingException("Expected mileva_id/mileva_mean fields were not created.")
        values = {}
        for feat in layer.getFeatures():
            try:
                key = int(feat[id_idx])
                value = float(feat[mean_idx])
            except (TypeError, ValueError):
                continue
            if np.isfinite(value):
                values[key] = value
        return values

    @staticmethod
    def _keep_best(records, limit):
        records.sort(key=lambda item: (item[1]["score"], item[0]))
        return records[:limit]

    def processAlgorithm(self, parameters, context, feedback):
        complete = self.parameterAsSource(parameters, self.COMPLETE, context)
        tiles = self.parameterAsSource(parameters, self.TILES, context)
        raster = self.parameterAsRasterLayer(parameters, self.RASTER, context)
        if complete is None or tiles is None or raster is None:
            raise QgsProcessingException("Select Complete points, tessellation tiles, and the proxy raster.")

        crs = complete.sourceCrs()
        if not crs.isValid() or crs.mapUnits() != Qgis.DistanceUnit.Meters:
            raise QgsProcessingException("Complete points must use a projected CRS with meter units.")
        if tiles.sourceCrs() != crs or raster.crs() != crs:
            raise QgsProcessingException(
                "Complete points, tessellation tiles, and proxy raster must share the same projected CRS.")

        radius = self.parameterAsDouble(parameters, self.RADIUS, context)
        tolerance = self.parameterAsDouble(parameters, self.TOLERANCE, context)
        requested_n = self.parameterAsInt(parameters, self.N_RECORDERS, context)
        max_scenarios = self.parameterAsInt(parameters, self.MAX_SCENARIOS, context)
        trials = self.parameterAsInt(parameters, self.TRIALS, context)
        seed = self.parameterAsInt(parameters, self.SEED, context)
        rng = random.Random(seed)

        feedback.pushInfo("1/4 Calculating landscape-proxy means for the Complete scenario...")
        complete_layer, _ = self._memory_points(
            "MILEVA complete", complete.getFeatures(), crs, id_kind="source")
        complete_means = self._zonal_means(
            complete_layer, raster, radius, context, feedback)
        complete_values = np.asarray(list(complete_means.values()), dtype=float)
        if complete_values.size == 0:
            raise QgsProcessingException("The Complete scenario has no valid proxy means.")

        if feedback.isCanceled():
            raise QgsProcessingException("Sampling search canceled.")

        feedback.pushInfo("2/4 Generating one pole of inaccessibility per tessellation tile...")
        pole_result = processing.run("native:poleofinaccessibility", {
            "INPUT": parameters[self.TILES],
            "TOLERANCE": tolerance,
            "OUTPUT": "TEMPORARY_OUTPUT",
        }, context=context, feedback=feedback, is_child_algorithm=True)["OUTPUT"]
        pole_source = QgsProcessingUtils.mapLayerFromString(pole_result, context)
        if pole_source is None:
            raise QgsProcessingException("Could not load tessellation pole points.")
        pole_layer, pole_info = self._memory_points(
            "MILEVA tessellation poles", pole_source.getFeatures(), crs, id_kind="tile")
        pole_means = self._zonal_means(pole_layer, raster, radius, context, feedback)

        candidates = []
        for idx in sorted(pole_info):
            if idx not in pole_means:
                continue
            tile_id, geom = pole_info[idx]
            candidates.append({
                "tile_id": tile_id,
                "geometry": geom,
                "value": float(pole_means[idx]),
            })
        if not candidates:
            raise QgsProcessingException("No tessellation pole has a valid proxy mean.")
        if requested_n > len(candidates):
            raise QgsProcessingException(
                f"Requested {requested_n} recorders, but only {len(candidates)} tessellation poles "
                "have valid proxy values.")

        tess_values = np.asarray([c["value"] for c in candidates], dtype=float)
        complete_sorted = np.sort(complete_values)
        tess_sorted = np.sort(tess_values)
        union_min = float(min(np.min(complete_values), np.min(tess_values)))
        union_max = float(max(np.max(complete_values), np.max(tess_values)))
        proxy_span = union_max - union_min

        feedback.pushInfo(
            f"Complete valid points: {complete_values.size}; full tessellation poles: {len(candidates)}; "
            f"requested recorders: {requested_n}.")

        full_fields = QgsFields()
        full_fields.append(QgsField("tile_id", QMetaType.Type.QString))
        full_fields.append(QgsField("L_proxy_mean", QMetaType.Type.Double))
        full_sink, full_dest = self.parameterAsSink(
            parameters, self.FULL_TESSELLATION, context,
            full_fields, Qgis.WkbType.Point, crs)
        if full_sink is None:
            raise QgsProcessingException("Could not create full tessellation output.")
        for candidate in candidates:
            f = QgsFeature(full_fields)
            f.setGeometry(candidate["geometry"])
            f.setAttributes([candidate["tile_id"], candidate["value"]])
            if not full_sink.addFeature(f):
                raise QgsProcessingException("Could not write a full-tessellation pole.")

        feedback.pushInfo("3/4 Searching recorder-constrained scenarios...")
        m = len(candidates)
        values = np.asarray([c["value"] for c in candidates], dtype=float)
        combination_count = math.comb(m, requested_n)
        evaluated = {}

        def evaluate(key):
            key = tuple(sorted(key))
            if key not in evaluated:
                metrics = _scenario_metrics(
                    values[list(key)], complete_sorted, tess_sorted, proxy_span)
                evaluated[key] = metrics
            return evaluated[key]

        if combination_count <= self.EXACT_LIMIT:
            search_mode = "exact"
            for counter, key in enumerate(itertools.combinations(range(m), requested_n), start=1):
                if feedback.isCanceled():
                    raise QgsProcessingException("Sampling search canceled.")
                evaluate(key)
                if counter % 250 == 0 or counter == combination_count:
                    feedback.setProgress(45 + int(45 * counter / combination_count))
        else:
            search_mode = "stochastic"
            # Strong deterministic starts that match the proxy quantiles of both references.
            for weight in (0.25, 0.5, 0.75):
                evaluate(_quantile_seed(values, complete_values, tess_values, requested_n, weight))

            # Reproducible random combinations.
            for i in range(trials):
                if feedback.isCanceled():
                    raise QgsProcessingException("Sampling search canceled.")
                evaluate(tuple(sorted(rng.sample(range(m), requested_n))))
                if (i + 1) % 100 == 0 or i + 1 == trials:
                    feedback.setProgress(45 + int(25 * (i + 1) / trials))

            # Local one-for-one swaps around the strongest candidates found above.
            elite = sorted(evaluated.items(), key=lambda item: item[1]["score"])[:10]
            local_steps = max(100, min(1000, trials // 3))
            all_indices = set(range(m))
            for elite_no, (start_key, start_metrics) in enumerate(elite, start=1):
                current = set(start_key)
                current_metrics = start_metrics
                for _ in range(local_steps):
                    selected = tuple(sorted(current))
                    unselected = tuple(sorted(all_indices - current))
                    if not unselected:
                        break
                    remove_idx = rng.choice(selected)
                    add_idx = rng.choice(unselected)
                    proposal = set(current)
                    proposal.remove(remove_idx)
                    proposal.add(add_idx)
                    proposal_key = tuple(sorted(proposal))
                    proposal_metrics = evaluate(proposal_key)
                    if proposal_metrics["score"] < current_metrics["score"]:
                        current = proposal
                        current_metrics = proposal_metrics
                feedback.setProgress(70 + int(20 * elite_no / max(1, len(elite))))

        ranked = sorted(evaluated.items(), key=lambda item: (item[1]["score"], item[0]))
        if not ranked:
            raise QgsProcessingException("No feasible recorder-constrained scenario was produced.")
        ranked = ranked[:min(max_scenarios, len(ranked))]

        scenario_fields = QgsFields()
        scenario_fields.append(QgsField("scenario", QMetaType.Type.QString))
        scenario_fields.append(QgsField("rank", QMetaType.Type.Int))
        scenario_fields.append(QgsField("tile_id", QMetaType.Type.QString))
        scenario_fields.append(QgsField("L_proxy_mean", QMetaType.Type.Double))
        scenario_fields.append(QgsField("score", QMetaType.Type.Double))
        scenario_fields.append(QgsField("n_recorders", QMetaType.Type.Int))
        scenario_sink, scenario_dest = self.parameterAsSink(
            parameters, self.SCENARIOS, context,
            scenario_fields, Qgis.WkbType.Point, crs)
        if scenario_sink is None:
            raise QgsProcessingException("Could not create optimized-scenarios output.")

        table_fields = QgsFields()
        table_fields.append(QgsField("Rank", QMetaType.Type.Int))
        table_fields.append(QgsField("Scenario", QMetaType.Type.QString))
        table_fields.append(QgsField("N_complete", QMetaType.Type.Int))
        table_fields.append(QgsField("N_tess", QMetaType.Type.Int))
        table_fields.append(QgsField("N_sub", QMetaType.Type.Int))
        table_fields.append(QgsField("Score", QMetaType.Type.Double))
        table_fields.append(QgsField("KS_complete", QMetaType.Type.Double))
        table_fields.append(QgsField("KS_p_complete", QMetaType.Type.Double))
        table_fields.append(QgsField("W_complete", QMetaType.Type.Double))
        table_fields.append(QgsField("S10_complete", QMetaType.Type.Double))
        table_fields.append(QgsField("KS_tess", QMetaType.Type.Double))
        table_fields.append(QgsField("KS_p_tess", QMetaType.Type.Double))
        table_fields.append(QgsField("W_tess", QMetaType.Type.Double))
        table_fields.append(QgsField("S10_tess", QMetaType.Type.Double))
        table_fields.append(QgsField("SearchMode", QMetaType.Type.QString))
        table_fields.append(QgsField("Seed", QMetaType.Type.Int))
        table_fields.append(QgsField("Evaluated", QMetaType.Type.Int))
        table_sink, table_dest = self.parameterAsSink(
            parameters, self.TABLE, context,
            table_fields, Qgis.WkbType.NoGeometry)
        if table_sink is None:
            raise QgsProcessingException("Could not create scenario comparison table.")

        feedback.pushInfo("4/4 Writing the best scenarios and comparison table...")
        for rank, (key, metrics) in enumerate(ranked, start=1):
            scenario_name = f"Scenario_{rank}"
            for candidate_idx in key:
                candidate = candidates[candidate_idx]
                f = QgsFeature(scenario_fields)
                f.setGeometry(candidate["geometry"])
                f.setAttributes([
                    scenario_name,
                    rank,
                    candidate["tile_id"],
                    candidate["value"],
                    metrics["score"],
                    requested_n,
                ])
                if not scenario_sink.addFeature(f):
                    raise QgsProcessingException("Could not write an optimized scenario point.")

            row = QgsFeature(table_fields)
            row.setAttributes([
                rank,
                scenario_name,
                int(complete_values.size),
                int(tess_values.size),
                requested_n,
                metrics["score"],
                metrics["ks_complete"],
                metrics["p_complete"],
                metrics["w_complete"],
                metrics["s10_complete"],
                metrics["ks_tess"],
                metrics["p_tess"],
                metrics["w_tess"],
                metrics["s10_tess"],
                search_mode,
                seed,
                len(evaluated),
            ])
            if not table_sink.addFeature(row):
                raise QgsProcessingException("Could not write a scenario comparison row.")

            feedback.pushInfo(
                f"{scenario_name}: score={metrics['score']:.4f}; "
                f"Complete KS={metrics['ks_complete']:.4f}, W={metrics['w_complete']:.4f}; "
                f"Tessellation KS={metrics['ks_tess']:.4f}, W={metrics['w_tess']:.4f}")

        if search_mode == "exact":
            feedback.pushInfo(
                f"Exact search evaluated all {combination_count} possible subsets.")
        else:
            feedback.pushInfo(
                f"Stochastic search evaluated {len(evaluated)} unique subsets out of "
                f"{combination_count} possible combinations. Reuse seed {seed} to reproduce it; "
                "increase Search trials for a more intensive search.")
        feedback.pushInfo(
            "Ranking is distributional: it minimizes KS D and range-normalized Wasserstein "
            "against both Complete and the full tessellation. It does not replace field, "
            "accessibility, acoustic, or spatial-autocorrelation validation.")

        name_output(parameters, self.FULL_TESSELLATION, full_dest, "Full tessellation poles", context)
        name_output(parameters, self.SCENARIOS, scenario_dest, "Top constrained scenarios", context)
        name_output(parameters, self.TABLE, table_dest, "Constrained scenario comparison", context)
        feedback.setProgress(100)
        return {
            self.FULL_TESSELLATION: full_dest,
            self.SCENARIOS: scenario_dest,
            self.TABLE: table_dest,
        }

    def name(self):
        return "recorder_constrained_scenarios"

    def displayName(self):
        return "STEP VII - Optimize recorder-constrained scenarios"

    def group(self):
        return "Workflow steps"

    def groupId(self):
        return "workflow"

    def shortHelpString(self):
        return (
            "Use this after creating the Complete point scenario and a tessellation. "
            "Enter the number of recorders available. MILEVA recomputes one pole of "
            "inaccessibility per tile, calculates the landscape-proxy mean around the "
            "Complete points and all tessellation poles with the same buffer radius, "
            "and searches subsets containing exactly that many poles. Each candidate "
            "is compared with both the Complete reference and the full tessellation "
            "using KS D and true 1D Wasserstein distance. The ranking score gives equal "
            "weight to KS D and range-normalized Wasserstein for both references; lower "
            "is better. KS p-values and S10_sorted_delta are reported but not optimized. "
            "Up to five best scenarios are returned in one point layer, identified by "
            "scenario/rank, plus a comparison table and the full set of tessellation poles. "
            "When the number of possible subsets is <= 50,000 the search is exhaustive; "
            "otherwise a reproducible seeded heuristic is used. This ranks landscape-proxy "
            "distributional resemblance only and does not automatically establish acoustic "
            "representativeness or field feasibility."
        ) + CITATION

    def createInstance(self):
        return RecorderConstrainedScenariosAlgorithm()
